# City Life - Day & Night - Pure CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/josetxu/pen/poKbEjG](https://codepen.io/josetxu/pen/poKbEjG).

Inspired by illustrator <a href="http://paulblow.com/work/">Paul Blow</a>'s <a href="https://paulblow.bigcartel.com/product/love-in-the-time-of-corona">"Love in the Time of Corona"</a>.



